//window.onload = init;

//function init(){
  //resizeToMinimum();
//}

//function resizeToMinimum(w,h){
    //w=w>window.outerWidth?w:window.outerWidth;
    //h=h>window.outerHeight?h:window.outerHeight;
    //window.resizeTo(w, h);
//};
//window.addEventListener('resize', function(){resizeToMinimum(100,100)}, false)
